<?php
$dsn="mysql:dbname=kaw37;host=sql1.njit.edu;port=3306";//"mysql:dbname=devTest;host=localhost;port=3306";
$usr="kaw37";
$pwd="Kawaiiasfuck0315__";
?>